package com.mb.neox.com.models

data class LoginResponse(
    val SessionId: String,
    val SessionTimeout: Int
)
