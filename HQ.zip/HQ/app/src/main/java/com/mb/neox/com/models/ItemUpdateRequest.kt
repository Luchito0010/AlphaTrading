package com.mb.neox.com.models

data class ItemUpdateRequest(
    val U_UBICACION: String
)
